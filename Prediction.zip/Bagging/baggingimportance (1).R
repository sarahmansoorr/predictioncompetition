setwd('/Users/sarahmansoor/Desktop/Fall 2020/sta314/prediction') 

d.train = read.csv('trainingdata.csv')
d.test = read.csv('test_predictors.csv')

install.packages('tree')
install.packages('randomForest')
library(randomForest)
library(tree)
library(MASS)

bag.boston.full = randomForest(y~.,data = d.train, mtry = 112, importance = TRUE) # 65.18%
# bag.boston.full = randomForest(y~.,data = d.train, mtry = 100, importance = TRUE) # 64.91
# bag.boston.full = randomForest(y~.,data = d.train, mtry = 50, importance = TRUE) # 60.78
# bag.boston.full = randomForest(y~.,data = d.train, mtry = 112, ntrees = 1, importance = TRUE) # 65.28
# bag.boston.full = randomForest(y~.,data = d.train, mtry = 112, ntrees = 5, importance = TRUE) # 65.1
# bag.boston.full = randomForest(y~.,data = d.train, mtry = 112, ntrees = 2, importance = TRUE) # 65.07

yhat.tree = predict(bag.boston.full,newdata=d.test)

example_pred = data.frame(cbind(1:6000,yhat.tree))
names(example_pred) = c('id','y')

write.csv(example_pred,file='baggingimportance.csv',row.names=FALSE)